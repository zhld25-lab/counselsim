# Lab 3b — Implementation Screenshot Evidence

**Student:** Zhenzhe Luo  
**Course:** CSE 498  
**Project:** CounselSim — Counsellor Training Web-Based App

The screenshots below document observed behaviour in simulated counselling sessions. Scores are LLM-generated educational feedback, not clinically validated assessments.

## Figure 1 — Mode A: counsellor feedback (7/10)

The supervisor evaluated six user-controlled counsellor turns and reported weighted performance across five dimensions.

![Figure 1: Mode A: counsellor feedback (7/10)](docs/screenshots/01-feedback-mode-a-7of10.png)

## Figure 2 — Mode A: qualitative assessment

The feedback expands numeric grades into active listening, open-ended questions, safety/ethics, and observed strengths.

![Figure 2: Mode A: qualitative assessment](docs/screenshots/02-feedback-strengths.png)

## Figure 3 — Mode A: actionable rewrites

Each improvement identifies the original turn, explains its weakness, and proposes a revised response; a suggested safety check is explicitly identified.

![Figure 3: Mode A: actionable rewrites](docs/screenshots/03-feedback-improvements-safety-check.png)

## Figure 4 — Mixed-control: targeted improvements

Turn-specific proposed edits illustrate how evaluations remain useful when human and AI roles alternate.

![Figure 4: Mixed-control: targeted improvements](docs/screenshots/04-feedback-improvements-alt.png)

## Figure 5 — Mixed-control: skills assessed

The system summarizes observed strengths and evaluates only relevant user-controlled turns.

![Figure 5: Mixed-control: skills assessed](docs/screenshots/05-feedback-strengths-alt.png)

## Figure 6 — Mixed-control: attribution-aware grading (8/10)

Only three counsellor turns made by the user are graded; three AI counsellor turns are excluded.

![Figure 6: Mixed-control: attribution-aware grading (8/10)](docs/screenshots/06-attribution-mixed-turns.png)

## Figure 7 — Session 1: structured case-note summary

The case note records concerns, disclosed information, mood changes, coping patterns, unresolved topics, and next steps.

![Figure 7: Session 1: structured case-note summary](docs/screenshots/07-session-summary-s1.png)

## Figure 8 — Session 2: longitudinal case note

A later summary records new information and an updated next step for the same simulated client.

![Figure 8: Session 2: longitudinal case note](docs/screenshots/08-session-summary-s2.png)

## Figure 9 — Mode C: AI-counsellor evaluation (8/10)

Because the trainee did not occupy the counsellor seat, the report evaluates six AI counsellor turns.

![Figure 9: Mode C: AI-counsellor evaluation (8/10)](docs/screenshots/09-feedback-mode-c-8of10.png)

## Figure 10 — Mode C: assessed skills

The report supplies qualitative assessment of active listening, questions, and safety/ethics.

![Figure 10: Mode C: assessed skills](docs/screenshots/10-feedback-mode-c-assessed.png)

## Figure 11 — Mode C: AI-counsellor improvement advice

The supervisor identifies verbose or leading responses and recommends simpler client-centred alternatives.

![Figure 11: Mode C: AI-counsellor improvement advice](docs/screenshots/11-feedback-mode-c-improvements.png)

## Figure 12 — Mode C: user versus AI supervisor

A side-by-side dimension comparison reveals an overall mean absolute score difference of 1.8 points.

![Figure 12: Mode C: user versus AI supervisor](docs/screenshots/12-scores-vs-ai-supervisor.png)

## Interpretation and limitations

The three grading situations differ: Mode A assesses six human turns; mixed-control grading excludes three AI turns and assesses three human turns; Mode C evaluates six AI turns because the trainee never held the counsellor role. The human/AI score gap (MAE 1.8) documents a difference in judgments rather than an objective ground truth. Screenshots of saved summaries demonstrate case-note generation, not by themselves successful retrieval in a subsequent session. An undisclosed topic visible in open threads may indicate inappropriate revelation of hidden persona information.

See the main README for architecture, setup, usage, and source-code implementation details.
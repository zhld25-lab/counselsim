## Screenshots and functional demonstration

A figure-by-figure gallery and interpretation are available in [Lab 3b Screenshot Evidence](LAB3B_SCREENSHOT_EVIDENCE.md). The images are stored in `docs/screenshots/` and are linked directly from that document.
